<?php 

echo "<h1>affichage de \$_POST</h1>";

echo "<pre>";
print_r($_POST);
echo "<pre>";

?>