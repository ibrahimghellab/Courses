<?php 

echo "<h1>affichage de \$_GET</h1>";

echo "<pre>";
print_r($_GET);
echo "<pre>";

?>