<?php

require_once("connexion.php");

Connexion::connect();

?>